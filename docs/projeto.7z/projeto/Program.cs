﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Linq.Expressions;  //compilador

class Produto //Classe que representa os produtos
{
    public string Nome { get; set; }
    public double Preco { get; set; }
}

class Program
{
    static List<Produto> produtos = new List<Produto>()   //Lista dos produtos
    {
        new Produto { Nome = "Geladeira RB50", Preco = 4019 },
        new Produto { Nome = "TV UN58", Preco = 2279 },
        new Produto { Nome = "Lava e seca WD11M", Preco = 3090 },
        new Produto { Nome = "Lavadora WW11T", Preco = 2099 },
        new Produto { Nome = "Celular S24", Preco = 3300 }
    };

    static string caminhoSaida = "saida.dat";

    static void Main(string[] args)
    {
        int opcao;
        do    //Loop do menu e das opções
        {
            Console.WriteLine("\nMenu de Vendas");
            Console.WriteLine("1 - Cadastrar Produto");
            Console.WriteLine("2 - Excluir Produto");
            Console.WriteLine("3 - Alterar Produto");
            Console.WriteLine("4 - Listar Produtos");
            Console.WriteLine("5 - Comprar Produto");
            Console.WriteLine("6 - Sair");
            Console.Write("Escolha uma opção: ");

            if (!int.TryParse(Console.ReadLine(), out opcao))
            {
                GravarSaida("Entrada inválida.");
                continue;
            }

            switch (opcao)
            {
                case 1:
                    CadastrarProduto();
                    break;
                case 2:
                    ExcluirProduto();
                    break;
                case 3:
                    AlterarProduto();
                    break;
                case 4:
                    ListarProdutos();
                    break;
                case 5:
                    ComprarProduto();
                    break;
                case 6:
                    GravarSaida("Encerrando...");
                    break;
                default:
                    GravarSaida("Opção inválida.");
                    break;
            }
        Console.WriteLine("Aperte enter para iniciar.");
        Console.ReadLine();
        Console.Clear();
        } while (opcao != 6);
        
    }

    static void GravarSaida(string mensagem)
    {
        string registro = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} - {mensagem}";    // retorna a data e hora atual do sistema no momento em que o código está sendo executado.
        Console.WriteLine(registro);
        File.AppendAllText(caminhoSaida, registro + Environment.NewLine);
    }

    static void CadastrarProduto()
    {
        Console.Write("Nome do produto: ");
        string nome = Console.ReadLine();

        Console.Write("Preço do produto: ");
        if (double.TryParse(Console.ReadLine(), out double preco))
        {
            produtos.Add(new Produto { Nome = nome, Preco = preco });
            GravarSaida($"Produto cadastrado: {nome}, Preço: {preco.ToString("C", CultureInfo.CurrentCulture)}");  //Converte o valor em monetário.
        }
        else
        {
            GravarSaida("Preço inválido.");
        }
    }

    static void ExcluirProduto()
    {
        Console.Write("Nome do produto a ser excluído: ");
        string nome = Console.ReadLine();

        var produto = produtos.FirstOrDefault(p => p.Nome.Equals(nome, StringComparison.OrdinalIgnoreCase)); // Aceitar string maiúsculo e minúsculo 
        if (produto != null)
        {
            produtos.Remove(produto);
            GravarSaida($"Produto excluído: {nome}");
        }
        else
        {
            GravarSaida($"Produto não encontrado: {nome}");
        }
    }

    static void AlterarProduto()
    {
        Console.Write("Nome do produto a ser alterado: ");
        string nome = Console.ReadLine();

        var produto = produtos.FirstOrDefault(p => p.Nome.Equals(nome, StringComparison.OrdinalIgnoreCase));
        if (produto != null)
        {
            Console.Write("Novo preço do produto: ");
            if (double.TryParse(Console.ReadLine(), out double preco))
            {
                produto.Preco = preco;
                GravarSaida($"Produto alterado: {nome}, Novo Preço: {preco.ToString("C", CultureInfo.CurrentCulture)}");
            }
            else
            {
                GravarSaida("Preço inválido.");
            }
        }
        else
        {
            GravarSaida($"Produto não encontrado: {nome}");
        }
    }

    static void ListarProdutos()
    {
        GravarSaida("Listagem de produtos:");
        foreach (var p in produtos)    //Loop para mostrar os produtos na lista
        {
            GravarSaida($"Nome: {p.Nome}, Preço: {p.Preco.ToString("C", CultureInfo.CurrentCulture)}");
        }
    }

    static void ComprarProduto()
    {
        Console.Write("Nome do produto: ");
        string nome = Console.ReadLine();

        var produto = produtos.FirstOrDefault(p => p.Nome.Equals(nome, StringComparison.OrdinalIgnoreCase));
        if (produto != null)
        {
            Console.Write("Quantidade: ");
            if (int.TryParse(Console.ReadLine(), out int quantidade))
            {
                double total = quantidade * produto.Preco;
                GravarSaida($"Compra: {quantidade}x {nome}, Total: {total.ToString("C", CultureInfo.CurrentCulture)}");
            }
            else
            {
                GravarSaida("Quantidade inválida.");
            }
        }
        else
        {
            GravarSaida($"Produto não encontrado: {nome}");
        }
        
    }
}




